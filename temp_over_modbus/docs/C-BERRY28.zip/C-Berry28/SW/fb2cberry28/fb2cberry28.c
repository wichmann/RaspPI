/*##############################################################*/
/* 																*/
/* File		: fb2cberry28.c										*/
/*																*/
/* Project	: TFT for Raspberry Pi Revision 2					*/
/* 																*/
/* Date		: 2014-08-13   	    last update: 2014-08-13			*/
/* 																*/
/* Author	: DerHagen 		  									*/
/*			  DerTimo											*/
/* 																*/
/* IDE	 	: Geany 1.22										*/
/* Compiler : gcc (Debian 4.6.3-14+rpi1) 4.6.3					*/
/*																*/
/* Copyright (C) 2013 admatec GmbH								*/
/*																*/
/*																*/	
/* Description  :												*/
/* 																*/
/*	This file clones the data from the monitor (dev/fb0)		*/
/*	to the C-Berry28.											*/
/*																*/
/*																*/
/* License:														*/
/*																*/
/*	This program is free software; you can redistribute it 		*/ 
/*	and/or modify it under the terms of the GNU General			*/ 	
/*	Public License as published by the Free Software 			*/
/*	Foundation; either version 3 of the License, or 			*/
/*	(at your option) any later version. 						*/
/*    															*/
/*	This program is distributed in the hope that it will 		*/
/*	be useful, but WITHOUT ANY WARRANTY; without even the 		*/
/*	implied w arranty of MERCHANTABILITY or 						*/
/*	FITNESS FOR A PARTICULAR PURPOSE. See the GNU General 		*/
/*	Public License for more details. 							*/
/*																*/
/*	You should have received a copy of the GNU General 			*/
/*	Public License along with this program; if not, 			*/
/*	see <http://www.gnu.org/licenses/>.							*/
/*																*/
/*																*/
/* Revision History:											*/
/*																*/
/*	Version 1.0 - Initial release								*/
/*																*/
/*																*/
/*																*/
/*##############################################################*/

#include <stdio.h>
#include <stdlib.h>
#include "ST7789.h"
#include <bcm_host.h>


int main(int argc, char **argv)
{
	DISPMANX_DISPLAY_HANDLE_T main_display_handle;
	DISPMANX_RESOURCE_HANDLE_T screen_resource_handle;
	
	VC_RECT_T rectangle;
	
	int ret;
	uint32_t image_prt;
	uint16_t image[ PICTURE_PIXELS ];
	
	
	bcm_host_init();
	
	if ( !bcm2835_init() )
	return ( -1 );
	
	TFT_init_board();	
	TFT_hard_reset();
	STcontroller_init();
	
	TFT_SetBacklightPWMValue( 255 );
	
	// open main framebuffer device
	main_display_handle = vc_dispmanx_display_open( 0 );
    if ( !main_display_handle )
    {
        printf("\n Unable to open primary display");
        return( -1 );
    }
    
    // now build up the shadow area for ST
    screen_resource_handle = vc_dispmanx_resource_create( VC_IMAGE_RGB565, DISPLAY_WIDTH , DISPLAY_HEIGHT, &image_prt );

    if ( !screen_resource_handle )
    {
        printf("\n Unable to create screen buffer");
        vc_dispmanx_display_close( main_display_handle );
        return ( -1 );
    }

	vc_dispmanx_rect_set( &rectangle, 0, 0, DISPLAY_WIDTH, DISPLAY_HEIGHT );   
    
    while( 1 )
    {    
		ret = vc_dispmanx_snapshot( main_display_handle, screen_resource_handle, DISPMANX_NO_ROTATE );  
    
		vc_dispmanx_resource_read_data( screen_resource_handle, &rectangle, &image[0], DISPLAY_WIDTH*2 ); 
		 
		STcontroller_Write_Picture( &image[0], PICTURE_PIXELS );	
		
		// 200ms ->  5 fps
		// 100ms -> 10 fps
		//  50ms -> 20 fps
		usleep( 100 * 1000 );
	}

	return ( 0 );
}

