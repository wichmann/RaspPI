/*##############################################################*/
/* 																*/
/* File		: examples.c 										*/
/*																*/
/* Project	: TFT for Raspberry Pi Revision 2					*/
/* 																*/
/* Date		: 2014-08-13   	    last update: 2014-08-13			*/
/* 																*/
/* Author	: Hagen Ploog   									*/
/*		  	  Timo Pfander										*/
/* 																*/
/* IDE	 	: Geany 1.22										*/
/* Compiler : gcc (Debian 4.6.3-14+rpi1) 4.6.3					*/
/*																*/
/* Copyright (C) 2013 admatec GmbH								*/
/*																*/
/*																*/	
/* Description  :												*/
/* 	Exmples.c includes the following functions to demonstrate 	*/
/*	some opportunities:											*/
/*		- depict one BMP file on the TFT 						*/
/*																*/
/*																*/
/* License:														*/
/*																*/
/*	This program is free software; you can redistribute it 		*/ 
/*	and/or modify it under the terms of the GNU General			*/ 	
/*	Public License as published by the Free Software 			*/
/*	Foundation; either version 3 of the License, or 			*/
/*	(at your option) any later version. 						*/
/*    															*/
/*	This program is distributed in the hope that it will 		*/
/*	be useful, but WITHOUT ANY WARRANTY; without even the 		*/
/*	implied warranty of MERCHANTABILITY or 						*/
/*	FITNESS FOR A PARTICULAR PURPOSE. See the GNU General 		*/
/*	Public License for more details. 							*/
/*																*/
/*	You should have received a copy of the GNU General 			*/
/*	Public License along with this program; if not, 			*/
/*	see <http://www.gnu.org/licenses/>.							*/
/*																*/
/*																*/
/* Revision History:											*/
/*																*/
/*	Version 1.0 - Initial release								*/
/*																*/
/*																*/
/*																*/
/*##############################################################*/


#include <stdio.h>
#include <stdint.h>
#include "ST7789.h"
#include "bmp.h"
#include "examples.h"


// load and depict a BMP file
// ---------------------------------------------
void example_DepictBMP( char const *file_name  )
{
	#ifdef CM_262K
		uint32_t picture[1][ PICTURE_PIXELS ];
	#else
		uint16_t picture[1][ PICTURE_PIXELS ];
	#endif
	
	Read_bmp2memory ( file_name, &picture[0][ PICTURE_PIXELS-1 ] );
	STcontroller_Write_Picture ( &picture[0][0], PICTURE_PIXELS );	
}
